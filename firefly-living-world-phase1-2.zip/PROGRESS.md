# FireFly — Progresso da expansão "Living World"

Este documento acompanha o plano de fases do pedido original.

## ✅ Feito nesta entrega

**Fase 1 — Refatoração segura da arquitetura**
`game.js` (4395 linhas, 1 arquivo) foi dividido em módulos ES nativos
(sem build step — funciona com `python3 -m http.server`, como o
projeto já usa):

```
game/
  main.js                 entrada: input, HUD, loop
  core/        constants, utils, dom, input, state, update
  data/        game-data.js (nomes, raridade, quests, loja, config de espécie)
  systems/     save, audio, quests, shop, capture, fishing
  entities/    creatures (IA + desenho), player, van
  world/       maps (interactables/transições/caverna), scenery, spots
  render/      world (compositor), panel, dialog, notify, draw-helpers
```
Nenhuma mecânica foi removida. `save/load`, áudio, loja, missão do
Tito, captura, pesca, van, vila, floresta e caverna continuam
funcionando exatamente como antes — validado por teste automatizado
(`test/smoke.mjs`, ver abaixo).

**Fase 2 — IA de criaturas por espécie (parcial, mas real)**
Substituído o antigo comportamento único ("todo bicho vaga com seno e
foge se o jogador chega perto") por regras por espécie em
`entities/creatures.js` + `data/game-data.js`:

- **Borboleta**: procura uma flor real do cenário, pousa, abre/fecha
  as asas mais devagar quando pousada, e só então levanta voo de novo.
- **Sapo**: fica confinado à área do lago, mais ativo à noite.
- **Lagartixa**: fica quase parada (camuflada) e dá disparos rápidos
  e curtos entre as pedras do mapa — mais difícil de capturar.
- **Aranha**: praticamente parada, sobe/desce na teia.
- **Rato (caverna)**: pausas com pequenos "skitters".
- **Vagalume / vagalume raro / vagalume de cristal**: enxame orbital
  suave ao redor do ponto de origem; vagalumes normais e raros ficam
  **invisíveis durante o dia** (bug do jogo original corrigido — antes
  eles continuavam sendo desenhados de dia).
- **Morcego**: dorme pendurado, acorda quando o jogador se aproxima,
  voa em círculo por um tempo e volta a dormir.

**Captura (Fase 21, parcial)**: chance de sucesso agora depende da
espécie (`catchDifficulty`) e do estado da criatura (pousada = mais
fácil; fugindo/em disparo = mais difícil), em vez de sempre acertar
ao alcance. Criatura que escapa foge de verdade, com SFX próprio.

**Pesca (Fase 19, parcial)**: nova fase de "disputa" com tensão de
linha — segurar ESPAÇO tensiona a linha, soltar deixa o peixe puxar;
tensão baixa demais ou alta demais faz o peixe escapar / a linha
arrebentar. Antes era só "espere e aperte espaço".

## 🧪 Como foi validado

`node test/smoke.mjs` — simula DOM/Canvas em Node e roda o jogo real
(sem mock de lógica, só de desenho) por centenas de frames em vila,
floresta e caverna, força o ciclo dia/noite, resolve um fluxo completo
de pesca e chama `capture()`, depois grava/lê o save. Rode com:

```bash
node test/smoke.mjs
```

Isso pega erros de import quebrado, referência indefinida, exceções em
runtime — o que dá muito mais confiança do que só ler o código, já que
não há navegador disponível neste ambiente para testar visualmente.
**Ainda assim, teste no navegador antes de mergear** — o smoke test
não substitui jogar de verdade.

## ⏳ Não incluído nesta entrega (próximas fases do pedido original)

- Floresta Cintilante expandida em áreas nomeadas (Clareira, Pedreira,
  Toca, Bosque Alto etc.) — Fase 3.
- Ambiente vivo (grama balançando, folhas caindo, insetos, pássaros
  distantes) — Fase 4.
- Caverna redesenhada integrada ao terreno + iluminação avançada —
  Fase 5/15.
- Van redesenhada com animação de embarque/desembarque e menu de
  destinos (Lagos Borbulhantes, Tundra) — Fases 16-18.
- Vila viva com NPCs andando/parando/sentando — Fase 26.
- Bestiário com horário/descrição por criatura — Fase 23.
- Áudio real (arquivos `.ogg`) — a estrutura de hooks já existe em
  `systems/audio.js`, só falta os assets licenciados.

Recomendo tratar essas fases como PRs seguintes, cada uma testável
isoladamente, em vez de uma entrega única gigante.
