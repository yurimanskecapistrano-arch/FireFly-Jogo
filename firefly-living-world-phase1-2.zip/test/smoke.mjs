// Smoke test: carrega o jogo real com um DOM/Canvas falso e roda
// vários frames em cada mapa, verificando que nada lança exceção.

import { pathToFileURL } from 'node:url';
import path from 'node:path';

const root = path.resolve(new URL('.', import.meta.url).pathname, '..');

/* -------- localStorage fake -------- */
const storage = new Map();
global.localStorage = {
  getItem: (k) => (storage.has(k) ? storage.get(k) : null),
  setItem: (k, v) => storage.set(k, String(v)),
  removeItem: (k) => storage.delete(k)
};

/* -------- elementos fake -------- */
function makeClassList() {
  const set = new Set();
  return {
    add: (c) => set.add(c),
    remove: (c) => set.delete(c),
    contains: (c) => set.has(c),
    _set: set
  };
}

function makeElement(tag = 'div') {
  const el = {
    tag,
    _children: [],
    dataset: {},
    style: {},
    innerHTML: '',
    textContent: '',
    classList: makeClassList(),
    onclick: null,
    addEventListener: () => {},
    querySelector: (sel) => {
      // suporte mínimo a .close e [data-buy]
      if (sel === '.close') return makeElement('button');
      return null;
    },
    querySelectorAll: (sel) => []
  };
  return el;
}

const elements = {
  '#coins': makeElement('span'),
  '#time': makeElement('span'),
  '#prompt': makeElement('small'),
  '#panel': makeElement('aside'),
  '#dialog': makeElement('div'),
  '#toast': makeElement('div'),
  '#mute': makeElement('button')
};

/* -------- canvas / ctx fake -------- */
function noop() {}
const gradientStub = { addColorStop: noop };

const ctxStub = new Proxy(
  {
    createLinearGradient: () => gradientStub,
    createRadialGradient: () => gradientStub,
    fillText: noop,
    fillRect: noop,
    strokeRect: noop,
    beginPath: noop,
    moveTo: noop,
    lineTo: noop,
    closePath: noop,
    fill: noop,
    stroke: noop,
    arc: noop,
    ellipse: noop,
    quadraticCurveTo: noop,
    bezierCurveTo: noop,
    roundRect: noop,
    save: noop,
    restore: noop,
    translate: noop,
    scale: noop,
    rotate: noop,
    clip: noop,
    setLineDash: noop
  },
  {
    get(target, prop) {
      if (prop in target) return target[prop];
      // qualquer propriedade não mapeada (fillStyle, strokeStyle, lineWidth,
      // font, textAlign, globalAlpha, shadowColor, shadowBlur,
      // globalCompositeOperation...) vira um no-op / valor ignorado.
      return undefined;
    },
    set() {
      return true;
    }
  }
);

const canvasEl = {
  ...makeElement('canvas'),
  getContext: () => ctxStub,
  focus: noop
};
elements['#game'] = canvasEl;

global.document = {
  querySelector: (sel) => elements[sel] || null,
  querySelectorAll: (sel) => (sel === '[data-panel]' ? [] : [])
};

const listeners = {};
global.addEventListener = (type, fn) => {
  listeners[type] = listeners[type] || [];
  listeners[type].push(fn);
};

global.requestAnimationFrame = () => {
  // não agenda de verdade: evitamos loop infinito no teste
  return 0;
};

global.window = global;

/* -------- roda o jogo -------- */
const mainUrl = pathToFileURL(path.join(root, 'game', 'main.js')).href;

const mod = await import(mainUrl);

console.log('✔ main.js carregado sem erros de import/execução inicial.');

// Acessa update/render indiretamente simulando frames, importando os
// módulos internos usados pelo loop.
const { update } = await import(pathToFileURL(path.join(root, 'game', 'core', 'update.js')).href);
const { render } = await import(pathToFileURL(path.join(root, 'game', 'render', 'world.js')).href);
const { state } = await import(pathToFileURL(path.join(root, 'game', 'core', 'state.js')).href);
const { beginMap } = await import(pathToFileURL(path.join(root, 'game', 'world', 'maps.js')).href);
const { save, saveGame } = await import(pathToFileURL(path.join(root, 'game', 'systems', 'save.js')).href);
const { startFishing, handleSpaceKey } = await import(
  pathToFileURL(path.join(root, 'game', 'systems', 'fishing.js')).href
);
const { keys } = await import(pathToFileURL(path.join(root, 'game', 'core', 'input.js')).href);

function runFrames(n, dt = 0.016) {
  for (let i = 0; i < n; i++) {
    update(dt);
    render();
  }
}

// vila
runFrames(120);
console.log('✔ 120 frames em VILA sem erros. map=', state.map);

// vai para a floresta diretamente (sem depender da van)
beginMap('forest', 200);
runFrames(5); // dispara o fade job
// força a transição a completar mais rápido para o teste
while (state.fade.job) {
  update(0.5);
}
runFrames(180);
console.log('✔ 180 frames em FLORESTA sem erros. entidades=', state.entities.length);

// testa dia e noite na floresta (fireflies devem ficar visible=false de dia)
state.clock = 0.5; // meio-dia
runFrames(30);
const fireflyDay = state.entities.find((e) => e.type === 'firefly');
console.log('firefly de dia -> visible =', fireflyDay?.visible, '(esperado false)');

state.clock = 0.0; // meia-noite
runFrames(30);
const fireflyNight = state.entities.find((e) => e.type === 'firefly');
console.log('firefly de noite -> visible =', fireflyNight?.visible, '(esperado true)');

// testa pesca completa (fluxo: wait -> bite -> reel -> sucesso/fracasso)
startFishing();
if (!state.fishing) throw new Error('startFishing não iniciou a pesca');
// avança até a mordida
while (state.fishing && state.fishing.stage === 'wait') {
  update(0.1);
}
console.log('✔ pesca chegou ao estágio:', state.fishing?.stage);
if (state.fishing?.stage === 'bite') {
  handleSpaceKey(); // fisga
  console.log('✔ após fisgar, estágio =', state.fishing?.stage);
  // segura espaço por tempo suficiente para vencer
  keys.add(' ');
  let ticks = 0;
  while (state.fishing && ticks < 2000) {
    update(0.016);
    ticks++;
  }
  console.log('✔ pesca resolvida após', ticks, 'ticks. fishing =', state.fishing);
  keys.delete(' ');
}

// vai para a caverna
beginMap('cave', 240);
while (state.fade.job) {
  update(0.5);
}
runFrames(180);
console.log('✔ 180 frames em CAVERNA sem erros. entidades=', state.entities.length);

// testa captura
const before = state.entities.filter((e) => e.alive).length;
// importa capture isoladamente
const { capture } = await import(pathToFileURL(path.join(root, 'game', 'systems', 'capture.js')).href);
capture();
const after = state.entities.filter((e) => e.alive).length;
console.log('✔ capture() executado sem erro. vivos antes=', before, 'depois=', after);

// testa save/load
saveGame();
const raw = localStorage.getItem('firefly-save');
if (!raw) throw new Error('saveGame não gravou nada no localStorage');
const parsed = JSON.parse(raw);
console.log('✔ save gravado e é JSON válido. coins=', parsed.coins, 'map=', parsed.map);

console.log('\n✅ SMOKE TEST PASSOU — nenhuma exceção lançada em nenhum fluxo testado.');
