/* =========================================================
   CENÁRIO — céu, chão, vegetação, construções, veículo, NPCs
   ========================================================= */

import { ctx } from '../core/dom.js';
import { state } from '../core/state.js';
import { W, H } from '../core/constants.js';
import { wx, poly, txt } from '../render/draw-helpers.js';
import { LAKE, FOREST_ROCKS, CAVE_ENTRANCE_X } from './spots.js';

/* =========================================================
   SKY
   ========================================================= */

export function sky() {
  const daylight = 1 - Math.abs(state.clock - 0.5) * 2;

  const gradient = ctx.createLinearGradient(0, 0, 0, H);

  gradient.addColorStop(
    0,
    `rgb(${18 + 80 * daylight}, ${35 + 170 * daylight}, ${60 + 155 * daylight})`
  );

  gradient.addColorStop(
    1,
    `rgb(${36 + 130 * daylight}, ${63 + 150 * daylight}, ${80 + 100 * daylight})`
  );

  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, W, H);

  /* Lua */

  if (daylight < 0.4) {
    ctx.fillStyle = '#f3edca';
    ctx.beginPath();
    ctx.arc(1030, 105, 28, 0, Math.PI * 2);
    ctx.fill();

    for (let i = 0; i < 40; i++) {
      ctx.fillStyle = '#dbe9ce';
      ctx.fillRect((i * 97) % W, (i * 59) % 300, 2, 2);
    }
  } else {
    ctx.fillStyle = '#ffe9a2';
    ctx.beginPath();
    ctx.arc(1030, 105, 35, 0, Math.PI * 2);
    ctx.fill();
  }

  /* Parallax */

  const layers = ['#5aa27e', '#377b69', '#245c58'];

  for (let layer = 0; layer < 3; layer++) {
    const offset = (state.camera.x * (0.18 + layer * 0.16)) % 150;

    ctx.fillStyle = layers[layer];

    for (let x = -160 - offset; x < W + 180; x += 118) {
      ctx.beginPath();
      ctx.moveTo(x, 450);
      ctx.quadraticCurveTo(x + 35, 285 - layer * 25, x + 70, 430);
      ctx.quadraticCurveTo(x + 99, 315, x + 130, 450);
      ctx.fill();
    }
  }
}

/* =========================================================
   GROUND
   ========================================================= */

export function ground() {
  const cave = state.map === 'cave';

  ctx.fillStyle = cave ? '#263d48' : '#356b4d';
  ctx.fillRect(0, 430, W, 290);

  ctx.fillStyle = cave ? '#415865' : '#4d915b';
  ctx.fillRect(0, 457, W, 263);

  for (let x = -40; x < W + 40; x += 27) {
    ctx.strokeStyle = cave ? '#5b7780' : '#79b76b';
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.moveTo(x, 460);
    ctx.lineTo(x + 5, 452 + Math.sin(state.t + x) * 3);
    ctx.stroke();
  }
}

/* =========================================================
   ÁRVORES
   ========================================================= */

export function tree(x, y, scale, variant = 0) {
  x = wx(x);

  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  ctx.rotate(Math.sin(state.t * 1.2 + x) * 0.012);

  poly(
    [
      [-15, 168],
      [-38, 188],
      [-12, 180],
      [0, 199],
      [14, 179],
      [39, 188],
      [20, 164],
      [17, 65],
      [-12, 53]
    ],
    '#654638',
    '#363e42'
  );

  ctx.fillStyle = '#a36c4d';
  ctx.fillRect(-2, 70, 5, 78);

  const crowns = [
    ['#4f9c5b', -28, 30, 44],
    ['#397f51', 19, 24, 51],
    ['#62ae66', 0, -8, 55],
    ['#4b9858', -38, -1, 37],
    ['#5dad65', 37, -2, 36]
  ];

  crowns.forEach(([color, a, b, radius]) => {
    ctx.fillStyle = variant ? color : color;

    ctx.beginPath();
    ctx.moveTo(a - radius * 0.6, b + radius * 0.3);
    ctx.quadraticCurveTo(a - radius, b - radius * 0.3, a, b - radius);
    ctx.quadraticCurveTo(a + radius, b - radius * 0.25, a + radius * 0.6, b + radius * 0.4);
    ctx.quadraticCurveTo(a, b + radius, a - radius * 0.6, b + radius * 0.3);
    ctx.fill();
  });

  ctx.restore();
}

/* =========================================================
   PEDRAS
   ========================================================= */

export function rocks(x, y, scale = 1) {
  x = wx(x);

  poly(
    [
      [x - 20 * scale, y],
      [x - 11 * scale, y - 18 * scale],
      [x + 10 * scale, y - 23 * scale],
      [x + 24 * scale, y - 5 * scale],
      [x + 17 * scale, y + 3 * scale],
      [x - 16 * scale, y + 3 * scale]
    ],
    '#779080',
    '#4c6b61'
  );

  ctx.fillStyle = '#9bb4a1';
  ctx.fillRect(x - 7 * scale, y - 15 * scale, 9 * scale, 3 * scale);
}

export function drawForestRocks() {
  FOREST_ROCKS.forEach((rock) => rocks(rock.x, rock.y, rock.scale));
}

/* =========================================================
   FLORES
   ========================================================= */

export function flower(x, y, color) {
  x = wx(x);

  ctx.strokeStyle = '#326b44';

  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x + 2, y - 19 + Math.sin(state.t + x) * 2);
  ctx.stroke();

  ctx.fillStyle = color;

  for (let i = 0; i < 5; i++) {
    ctx.beginPath();
    ctx.ellipse(
      x + 2 + Math.cos(i * 1.26) * 5,
      y - 23 + Math.sin(i * 1.26) * 5,
      4,
      3,
      i,
      0,
      Math.PI * 2
    );
    ctx.fill();
  }

  ctx.fillStyle = '#ffe276';
  ctx.beginPath();
  ctx.arc(x + 2, y - 23, 3, 0, Math.PI * 2);
  ctx.fill();
}

/* =========================================================
   LAGO
   ========================================================= */

export function lake() {
  const x = wx(LAKE.x);
  const y = LAKE.y;

  poly(
    [
      [x - 225, y + 30],
      [x - 192, y - 16],
      [x - 140, y - 36],
      [x - 89, y - 30],
      [x - 45, y - 59],
      [x + 35, y - 49],
      [x + 70, y - 22],
      [x + 155, y - 27],
      [x + 208, y + 8],
      [x + 182, y + 45],
      [x + 92, y + 61],
      [x + 19, y + 48],
      [x - 66, y + 66],
      [x - 147, y + 49]
    ],
    '#87684c',
    '#3f674d'
  );

  poly(
    [
      [x - 185, y + 22],
      [x - 151, y - 4],
      [x - 93, y - 15],
      [x - 40, y - 40],
      [x + 25, y - 32],
      [x + 73, y - 8],
      [x + 144, y - 10],
      [x + 173, y + 11],
      [x + 148, y + 29],
      [x + 89, y + 39],
      [x + 21, y + 29],
      [x - 53, y + 47],
      [x - 125, y + 34]
    ],
    '#3e98a9',
    '#286b79'
  );

  for (let i = 0; i < 8; i++) {
    ctx.strokeStyle = '#a5e4d9';
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.arc(
      x - 135 + i * 40 + Math.sin(state.t + i) * 7,
      y + 8 + (i % 3) * 9,
      10,
      0.1,
      2.7
    );
    ctx.stroke();
  }

  [
    [-165, 15],
    [165, 15],
    [-145, -8]
  ].forEach(([dx, dy]) => {
    ctx.strokeStyle = '#315f45';
    ctx.lineWidth = 3;

    ctx.beginPath();
    ctx.moveTo(x + dx, y + dy);
    ctx.lineTo(x + dx + 3, y + dy - 23);
    ctx.stroke();

    ctx.fillStyle = '#79994e';
    ctx.beginPath();
    ctx.ellipse(x + dx + 8, y + dy - 24, 7, 3, 0.5, 0, Math.PI * 2);
    ctx.fill();
  });

  if (state.fishing) {
    const bob =
      state.fishing.stage === 'reel'
        ? Math.sin(state.t * 22) * 5
        : state.fishing.ready
          ? Math.sin(state.t * 18) * 9
          : Math.sin(state.t * 4) * 2;

    ctx.strokeStyle = '#e9d5ae';

    ctx.beginPath();
    ctx.moveTo(wx(state.player.x) + 30, state.player.y - 10);
    ctx.lineTo(x, y - 10 + bob);
    ctx.stroke();

    ctx.fillStyle = '#f2c764';
    ctx.beginPath();
    ctx.arc(x, y - 10 + bob, 5, 0, Math.PI * 2);
    ctx.fill();
  }
}

/* =========================================================
   ENTRADA DA CAVERNA
   ========================================================= */

export function caveEntrance() {
  const x = wx(CAVE_ENTRANCE_X);
  const y = 460;

  poly(
    [
      [x - 130, 105],
      [x - 120, 54],
      [x - 92, 18],
      [x - 54, 4],
      [x - 20, -3],
      [x + 13, 17],
      [x + 47, 3],
      [x + 86, 24],
      [x + 115, 62],
      [x + 123, 105]
    ],
    '#5c625c',
    '#35464a'
  );

  poly(
    [
      [x - 78, 105],
      [x - 69, 58],
      [x - 42, 27],
      [x - 4, 19],
      [x + 37, 43],
      [x + 65, 72],
      [x + 72, 105]
    ],
    '#162b38'
  );

  for (let i = 0; i < 4; i++) {
    poly(
      [
        [x - 30 + i * 16, 94],
        [x - 24 + i * 16, 68],
        [x - 17 + i * 16, 94]
      ],
      '#91ddb9'
    );
  }
}

/* =========================================================
   MUNDO DA CAVERNA
   ========================================================= */

export function caveWorld() {
  for (let x = 0; x < W; x += 70) {
    poly(
      [
        [x, 0],
        [x + 35, 40 + (x % 4) * 14],
        [x + 70, 0]
      ],
      '#2e4957'
    );

    poly(
      [
        [x, 720],
        [x + 32, 650 - (x % 5) * 10],
        [x + 70, 720]
      ],
      '#314d59'
    );
  }

  for (let i = 0; i < 12; i++) {
    const x = (i * 139) % W;
    const y = 330 + (i % 3) * 85;

    poly(
      [
        [x, y],
        [x + 8, y - 26],
        [x + 16, y]
      ],
      i % 2 ? '#6ccfca' : '#a493e5'
    );
  }
}

/* =========================================================
   CASA / LOJINHA
   ========================================================= */

export function house() {
  const x = wx(630);
  const y = 400;

  poly(
    [
      [x - 123, y + 100],
      [x - 113, y + 36],
      [x - 74, y - 2],
      [x - 8, y + 15],
      [x + 42, y - 6],
      [x + 109, y + 36],
      [x + 123, y + 100]
    ],
    '#d78e5a',
    '#623f3c'
  );

  poly(
    [
      [x - 133, y + 40],
      [x - 81, y - 31],
      [x - 3, y + 2],
      [x + 45, y - 31],
      [x + 129, y + 41],
      [x + 109, y + 48],
      [x + 39, y + 8],
      [x - 5, y + 28],
      [x - 84, y - 20],
      [x - 118, y + 49]
    ],
    '#9b5147',
    '#623f3c'
  );

  ctx.fillStyle = '#f1c378';
  ctx.fillRect(x - 50, y + 58, 35, 42);

  ctx.fillStyle = '#7bc0c4';
  ctx.fillRect(x + 29, y + 41, 34, 26);

  ctx.strokeStyle = '#653f3e';
  ctx.strokeRect(x + 29, y + 41, 34, 26);

  txt('LOJINHA DA LUMINA', x, y + 20, 11, '#fff5c9', 'center');
}

/* =========================================================
   VAN
   ========================================================= */

export function drawVan() {
  const x = wx(980);
  const y = 520;

  const shake = state.travel ? Math.sin(state.t * 38) * 4 : Math.sin(state.t * 8);

  ctx.save();
  ctx.translate(x, y + shake);

  ctx.fillStyle = '#203d4c88';
  ctx.beginPath();
  ctx.ellipse(-5, 14, 120, 15, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#28495a';
  ctx.beginPath();
  ctx.roundRect(-112, -59, 215, 65, 18);
  ctx.fill();

  ctx.fillStyle = '#e37d4e';
  ctx.beginPath();
  ctx.roundRect(-106, -55, 203, 55, 13);
  ctx.fill();

  poly(
    [
      [-83, -59],
      [-55, -94],
      [28, -94],
      [59, -58]
    ],
    '#e37d4e',
    '#28495a'
  );

  ctx.fillStyle = '#9bd5da';
  ctx.fillRect(-49, -86, 35, 23);
  ctx.fillRect(-8, -86, 33, 23);

  ctx.fillStyle = state.travel ? '#fff4ac' : '#f9e4a6';
  ctx.fillRect(70, -31, 17, 12);

  ctx.strokeStyle = '#28495a';
  ctx.strokeRect(30, -50, 30, 50);

  txt('FIREFLY', 12, -17, 15, '#fff8d4', 'center');

  [-70, -12, 43, 78].forEach((offset) => {
    ctx.fillStyle = '#27343e';
    ctx.beginPath();
    ctx.arc(offset, 3, 15, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#d8d4bd';
    ctx.beginPath();
    ctx.arc(offset, 3, 6, 0, Math.PI * 2);
    ctx.fill();
  });

  ctx.restore();
}

/* =========================================================
   TITO
   ========================================================= */

export function drawTito() {
  const x = wx(460);
  const y = 505 + Math.sin(state.t * 2) * 2;

  ctx.save();
  ctx.translate(x, y);

  poly(
    [
      [-18, 40],
      [-21, 11],
      [-8, -1],
      [17, 3],
      [26, 39]
    ],
    '#7c6cad',
    '#343d55'
  );

  ctx.fillStyle = '#f2be91';
  ctx.beginPath();
  ctx.arc(1, -12, 18, 0, Math.PI * 2);
  ctx.fill();

  poly(
    [
      [-21, -10],
      [-7, -34],
      [18, -28],
      [26, -4],
      [10, -13]
    ],
    '#d86f55',
    '#343d55'
  );

  ctx.fillStyle = '#40585c';
  ctx.fillRect(-19, 40, 15, 8);
  ctx.fillRect(10, 40, 15, 8);

  ctx.restore();

  txt('TITO', x, y + 65, 11, '#fff8d9', 'center');
}
