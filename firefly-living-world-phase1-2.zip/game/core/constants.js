/* =========================================================
   CONSTANTES
   ========================================================= */

export const W = 1280;
export const H = 720;

export const MAP_LIMITS = {
  village: 1160,
  forest: 2200,
  cave: 1600
};
